import React from 'react'

function Tokens() {
  return (
    <div>Tokens</div>
  )
}

export default Tokens